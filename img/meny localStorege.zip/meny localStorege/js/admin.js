let menu = document.querySelector(".menu");
let food_name = document.querySelector(".food_name");
let price = document.querySelector(".price");
let photo = document.querySelector(".photo");
let create = document.querySelector(".btn_create");

create.addEventListener("click", () => {
  let obj = {
    food_name: food_name.value,
    price: price.value,
    photo: photo.value,
  };


  let data = JSON.parse(localStorage.getItem("menu")) || [];
  data.push(obj);
  localStorage.setItem("menu", JSON.stringify(data));
  readMenu()
});

