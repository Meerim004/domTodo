let menu = document.querySelector(".menu");
readMenu();

function readMenu() {
  let newData = JSON.parse(localStorage.getItem("menu")) || [];
  menu.innerHTML = "";
  newData.forEach((el, index) => {
    let menu_card = document.createElement("div");
    menu_card.classList.add("menu_card");
    let menu_img = document.createElement("img");
    menu_img.classList.add("menu_img");
    let txt_menu = document.createElement("div");
    txt_menu.classList.add("txt_menu");
    let txt_text = document.createElement("div");
    txt_text.classList.add("txt_text");
    let txt_name = document.createElement("p");
    txt_name.classList.add("txt_name");
    let txt_price = document.createElement("p");
    txt_price.classList.add("txt_price");
    let btn_action = document.createElement("div");
    btn_action.classList.add("btn_action");
    let btn_buy = document.createElement("button");
    btn_buy.classList.add("btn_buy");
    let btn_delete = document.createElement("button");
    btn_delete.classList.add("btn_delete");
    let btn_edit = document.createElement("button");
    btn_edit.classList.add("btn_edit");

    menu_img.src = el.photo;
    txt_name.innerText = el.food_name;
    txt_price.innerText = el.price;
    btn_buy.innerHTML = `<ion-icon name="bookmark-outline"></ion-icon>`;
    btn_edit.innerHTML = `<ion-icon name="create-outline"></ion-icon>`;
    btn_delete.innerHTML = `<ion-icon name="trash-outline"></ion-icon>`;

    btn_delete.addEventListener("click", () => {
      deleteBlock(index);
    });

    btn_buy.addEventListener("click" , ()=>{
      let basket = newData.find((el, idx) => idx === index)
      let data = JSON.parse(localStorage.getItem("basket")) || []
      data.push(basket)
      localStorage.setItem("basket" , JSON.stringify(data))
    })

    btn_edit.addEventListener("click", () => {
      edit_box.style.display = "block";
      editBlock(index);
    });

   




    txt_text.append(txt_name);
    txt_text.append(txt_price);
    btn_action.append(btn_buy);
    btn_action.append(btn_edit);
    btn_action.append(btn_delete);

    txt_menu.append(txt_text);
    txt_menu.append(btn_action);

    menu_card.append(menu_img);
    menu_card.append(txt_menu);

    menu.append(menu_card);
  });
}

function deleteBlock(id) {
  let data = JSON.parse(localStorage.getItem("menu")) || [];
  data.splice(id, 1);
  localStorage.setItem("menu", JSON.stringify(data));
  readMenu();
}

// edit

let edit_box = document.querySelector(".edit_box");

let edit_name = document.querySelector(".edit_food_namee");
let edit_price = document.querySelector(".edit_price");
let edit_photo = document.querySelector(".edit_photo");
let save = document.querySelector(".save");

function editBlock(index) {
  let data = JSON.parse(localStorage.getItem("menu")) || [];
  edit_name.value = data[index].food_name;
  edit_price.value = data[index].price;
  edit_photo.value = data[index].photo;

  edit_name.setAttribute("id", index);
  edit_price.setAttribute("id", index);
  edit_photo.setAttribute("id", index);
}

save.addEventListener("click", () => {
  let data = JSON.parse(localStorage.getItem("menu")) || [];


  let food_nameId = edit_name.id;
  let priceId = edit_price.id;
  let photoId = edit_photo.id;

  let editObj = {
    food_name: edit_name.value,
    price: edit_price.value,
    photo: edit_photo.value,
  };


  data.splice(food_nameId, 1, editObj);
  data.splice(priceId, 1, editObj);
  data.splice(photoId, 1, editObj);

  localStorage.setItem("menu", JSON.stringify(data));
  readMenu();
  edit_box.style.display = "none";

});


