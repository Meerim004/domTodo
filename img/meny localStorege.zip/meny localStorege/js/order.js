let order_list = document.querySelector(".order_list");
readBasket();

function readBasket() {
  let newData = JSON.parse(localStorage.getItem("basket")) || [];
  let num = 0
  newData.forEach((el,index) => {
    let order_card = document.createElement("div");
    order_card.classList.add("order_card");
    let order_img = document.createElement("img");
    order_img.classList.add("order_img");
    let order_txt = document.createElement("div");
    order_txt.classList.add(" order_txt");
    let name_txt = document.createElement("p");
    name_txt.classList.add("name_txt");
    let price_txt = document.createElement("p");
    price_txt.classList.add("price_txt");
    let order_btn = document.createElement("div");
    order_btn.classList.add("order_btn");
    let order_delete = document.createElement("button");
    order_delete.classList.add("order_delete");
    let order_mn = document.createElement("div");
    order_mn.classList.add("order_mn ");
    let minus = document.createElement("button");
    minus.classList.add("minus");
    let plus = document.createElement("button");
    plus.classList.add("plus");

    order_img.src = el.photo;
    name_txt.innerText = el.food_name;
    price_txt.innerText = el.price;

    order_txt.append(name_txt);
    order_txt.append(price_txt);
    order_btn.append(order_delete);
    order_mn.append(minus);
    order_mn.append(plus);

    order_card.append(order_img);
    order_card.append(order_txt);
    order_card.append(order_btn);

    order_list.append(order_card);
    readBasket();
  })
}
